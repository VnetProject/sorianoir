#!/bin/bash
# افزودن دامنه جدید به پیام‌رسان (بعد از نصب)
set -e
[ "$EUID" -ne 0 ] && { echo "با root اجرا کنید:  sudo bash add-domain.sh"; exit 1; }
read -rp "دامنه جدید: " ND
ND=$(echo "$ND" | sed 's#https\?://##; s#/.*##' | tr 'A-Z' 'a-z')
[[ "$ND" =~ ^[a-z0-9.-]+\.[a-z]{2,}$ ]] || { echo "دامنه نامعتبر"; exit 1; }
read -rp "ایمیل شما (برای SSL): " EMAIL
SIP=$(curl -4 -s https://ifconfig.me); DIP=$(dig +short A "$ND" | tail -1)
[ "$SIP" = "$DIP" ] || { echo "هشدار: DNS این دامنه ($DIP) به این سرور ($SIP) اشاره نمی‌کند. اول رکورد A را درست کنید (Cloudflare: ابر خاکستری)."; read -rp "ادامه بدهم؟ (y/n): " C; [ "$C" = "y" ] || exit 1; }
DOMAINS="$(cat /opt/payam-domains.txt) $ND"
echo "$DOMAINS" > /opt/payam-domains.txt
cat > /etc/nginx/sites-available/payam <<EOT
server {
  listen 80; server_name $DOMAINS;
  client_max_body_size 60M;
  location / {
    proxy_pass http://127.0.0.1:3000; proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade; proxy_set_header Connection "upgrade";
    proxy_set_header Host \$host; proxy_set_header X-Forwarded-Proto \$scheme; proxy_set_header X-Forwarded-For \$remote_addr;
  }
}
EOT
nginx -t && systemctl reload nginx
CB=""; for D in $DOMAINS; do CB="$CB -d $D"; done
certbot --nginx --cert-name payam $CB --non-interactive --agree-tos -m "$EMAIL" --redirect --expand
echo "انجام شد. دامنه‌های فعال: $DOMAINS"
