const fs=require('fs'),path=require('path'),http=require('http');
if(fs.existsSync('.env'))fs.readFileSync('.env','utf8').split('\n').forEach(l=>{const m=l.match(/^([A-Z_]+)=(.*)$/);if(m&&!process.env[m[1]])process.env[m[1]]=m[2]});
const express=require('express'),Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer'),nodemailer=require('nodemailer'),crypto=require('crypto');
const E=process.env,SECRET=E.JWT_SECRET||'dev-secret';
fs.mkdirSync('uploads',{recursive:true});
const db=new Database('data.db');db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,email TEXT UNIQUE,pass TEXT,first TEXT DEFAULT '',last TEXT DEFAULT '',email_ok INT DEFAULT 0,vtoken TEXT,allow_calls INT DEFAULT 1,allow_add INT DEFAULT 1,is_admin INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY,type TEXT,title TEXT,verified INT DEFAULT 0,owner INT,official INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS members(chat_id INT,user_id INT,PRIMARY KEY(chat_id,user_id));
CREATE TABLE IF NOT EXISTS contacts(user_id INT,contact_id INT,PRIMARY KEY(user_id,contact_id));
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,chat_id INT,user_id INT,text TEXT,kind TEXT DEFAULT 'text',file TEXT,fname TEXT,ts INTEGER);`);
['ALTER TABLE users ADD COLUMN avatar TEXT','ALTER TABLE users ADD COLUMN bio TEXT DEFAULT ""','ALTER TABLE users ADD COLUMN verified INT DEFAULT 0','ALTER TABLE users ADD COLUMN scam INT DEFAULT 0','ALTER TABLE users ADD COLUMN banned INT DEFAULT 0',
 'ALTER TABLE chats ADD COLUMN avatar TEXT','ALTER TABLE chats ADD COLUMN private INT DEFAULT 0','ALTER TABLE chats ADD COLUMN invite TEXT','ALTER TABLE chats ADD COLUMN scam INT DEFAULT 0','ALTER TABLE chats ADD COLUMN banned INT DEFAULT 0',
 'ALTER TABLE members ADD COLUMN last_read INT DEFAULT 0','ALTER TABLE users ADD COLUMN premium_until INT DEFAULT 0','ALTER TABLE users ADD COLUMN pbadge TEXT DEFAULT "star"','ALTER TABLE users ADD COLUMN seller INT DEFAULT 0','ALTER TABLE users ADD COLUMN hours TEXT',
 'ALTER TABLE chats ADD COLUMN handle TEXT','ALTER TABLE chats ADD COLUMN is_public INT DEFAULT 0','ALTER TABLE messages ADD COLUMN reply_to INT','ALTER TABLE messages ADD COLUMN edited INT DEFAULT 0','ALTER TABLE users ADD COLUMN logo TEXT','ALTER TABLE users ADD COLUMN hide_verified INT DEFAULT 0','ALTER TABLE users ADD COLUMN hide_prem INT DEFAULT 0','ALTER TABLE users ADD COLUMN hide_seller INT DEFAULT 0','ALTER TABLE users ADD COLUMN allow_dm INT DEFAULT 1','ALTER TABLE users ADD COLUMN frozen INT DEFAULT 0','ALTER TABLE users ADD COLUMN balance REAL DEFAULT 0'].forEach(x=>{try{db.exec(x)}catch{}});
db.exec(`CREATE TABLE IF NOT EXISTS mutes(chat_id INT,user_id INT,until INT,PRIMARY KEY(chat_id,user_id));CREATE TABLE IF NOT EXISTS kicks(chat_id INT,user_id INT,PRIMARY KEY(chat_id,user_id));
CREATE TABLE IF NOT EXISTS handles(handle TEXT PRIMARY KEY,kind TEXT,owner_id INT);CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,seller_id INT,title TEXT,descr TEXT,price REAL,kind TEXT,content TEXT,file TEXT,fname TEXT,official INT DEFAULT 0,active INT DEFAULT 1,ts INT);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,product_id INT,buyer_id INT,seller_id INT,price REAL,status TEXT,dtext TEXT,dfile TEXT,dfname TEXT,ts INT,dts INT);CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY,title TEXT,days INT,price REAL,active INT DEFAULT 1);
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY,user_id INT,stars REAL,toman INT,mode TEXT,invoice_id TEXT,pay_url TEXT,card TEXT,holder TEXT,view_token TEXT,status TEXT,ts INT);CREATE TABLE IF NOT EXISTS cashouts(id INTEGER PRIMARY KEY,user_id INT,stars REAL,toman INT,card TEXT,holder TEXT,status TEXT,ts INT);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY,user_id INT,amount REAL,kind TEXT,note TEXT,ts INT);CREATE TABLE IF NOT EXISTS price_hist(ts INT,price REAL);
CREATE TABLE IF NOT EXISTS shops(id INTEGER PRIMARY KEY,user_id INT,name TEXT,descr TEXT,chat_id INT,status TEXT,ts INT);`);
db.exec("CREATE INDEX IF NOT EXISTS i_msg ON messages(chat_id,id);CREATE INDEX IF NOT EXISTS i_mem ON members(user_id);UPDATE chats SET invite=lower(hex(randomblob(6))) WHERE invite IS NULL AND type IN('group','channel')");
const get=k=>(db.prepare('SELECT v FROM settings WHERE k=?').get(k)||{}).v;
const set=(k,v)=>db.prepare('INSERT OR REPLACE INTO settings VALUES(?,?)').run(k,String(v));
if(get('email_verify')===undefined)set('email_verify',1);
if(!db.prepare('SELECT 1 FROM chats WHERE official=1').get())db.prepare("INSERT INTO chats(type,title,verified,official,invite) VALUES('channel','کانال رسمی',1,1,lower(hex(randomblob(6))))").run();
const OFFICIAL=()=>db.prepare('SELECT id FROM chats WHERE official=1').get().id;
if(!db.prepare('SELECT 1 FROM chats WHERE is_public=1').get())db.prepare("INSERT INTO chats(type,title,verified,is_public,invite) VALUES('group','گپ عمومی',1,1,lower(hex(randomblob(6))))").run();
const PUBLIC=()=>db.prepare('SELECT id FROM chats WHERE is_public=1').get().id;
db.prepare('INSERT OR IGNORE INTO members(chat_id,user_id) SELECT ?,id FROM users WHERE id NOT IN(SELECT user_id FROM kicks WHERE chat_id=?)').run(PUBLIC(),PUBLIC());
const ALL_EMO='pstar crown gem smile laugh wink cool sad love fire star heart broken star_l bolt sun moon cloud drop snow flame leaf flower tree mountain wave rainbow gift cake cup pizza icecream apple note headphones film game dice ball trophy diamond ring key lock bell flag pin globe plane car rocket house book pencil bulb check thumb eye glasses f_smile f_sad f_wink f_kiss f_love f_cool f_cry f_angry f_sleep f_wow ghost skull paw cat fish balloon cam mail coin cart tag bag call music medal magic target hourglass at'.split(' ');
const FREE_EMO=new Set('smile laugh wink cool sad f_smile f_sad f_wink f_kiss f_love f_cool f_cry f_angry f_sleep f_wow'.split(' '));const PREM_EMO=new Set(ALL_EMO.filter(x=>!FREE_EMO.has(x)));
const sget=(k,d)=>{const v=get(k);return v===undefined?d:+v};
const ADMINID=()=>(db.prepare('SELECT id FROM users WHERE is_admin=1 ORDER BY id').get()||{}).id;
const SUPPORT=()=>{const v=get('support_user');return v&&db.prepare('SELECT 1 FROM users WHERE id=?').get(+v)?+v:ADMINID()};
const price=()=>sget('star_price',25000);
function setPrice(p){p=Math.round(p);set('star_price',p);db.prepare('INSERT INTO price_hist VALUES(?,?)').run(Date.now(),p)}
if(!db.prepare('SELECT 1 FROM price_hist').get())db.prepare('INSERT INTO price_hist VALUES(?,?)').run(Date.now(),price());
function bal(uid,amt,kind,note){db.prepare('UPDATE users SET balance=ROUND(COALESCE(balance,0)+?,3) WHERE id=?').run(amt,uid);db.prepare('INSERT INTO ledger(user_id,amount,kind,note,ts) VALUES(?,?,?,?,?)').run(uid,amt,kind,note||'',Date.now())}
function spend(u,amt,kind,note){if(u.is_admin)return;const b=db.prepare('SELECT COALESCE(balance,0) b FROM users WHERE id=?').get(u.id).b;if(b+1e-9<amt)throw{http:402,msg:'موجودی سوریا استار کافی نیست'};bal(u.id,-amt,kind,note)}
const nStars=x=>{const n=Math.round(+x*1000)/1000;if(!(n>0)||n>500)throw{http:400,msg:'مقدار نامعتبر است (۰ تا ۵۰۰)'};return n};
const qBuy=n=>{const P=price(),K=sget('star_k',.002);return{cost:Math.ceil(P*n*(1+K*n/2)),newP:P*(1+K*n)}};
const qSell=n=>{const P=price(),K=sget('star_k',.002),sp=sget('star_spread',.05),fl=sget('star_floor',8000);return{pay:Math.floor(P*n*Math.max(.2,1-K*n/2)*(1-sp)),newP:Math.max(fl,P*(1-K*n))}};
const taken=(h,cid=0)=>!!(db.prepare('SELECT 1 FROM users WHERE username=?').get(h)||db.prepare('SELECT 1 FROM chats WHERE handle=? AND id!=?').get(h,cid)||db.prepare('SELECT 1 FROM handles WHERE handle=?').get(h));
const AA=fn=>(q,r)=>Promise.resolve().then(()=>fn(q,r)).catch(e=>{if(e&&e.http)return r.status(e.http).json({error:e.msg});console.error(e);r.status(500).json({error:'خطای سرور'})});
const kindOf=n=>/\.(png|jpe?g|gif|webp)$/i.test(n||'')?'image':/\.(mp4|mov|webm|mkv)$/i.test(n||'')?'video':/\.(mp3|m4a|ogg|wav)$/i.test(n||'')?'voice':'file';
const mailer=E.SMTP_HOST?nodemailer.createTransport({host:E.SMTP_HOST,port:+E.SMTP_PORT||587,auth:{user:E.SMTP_USER,pass:E.SMTP_PASS}}):null;
const app=express();app.set('trust proxy',1);const srv=http.createServer(app),io=require('socket.io')(srv,{cors:{origin:'*'}});
app.use((q,r,n)=>{r.setHeader('Access-Control-Allow-Origin','*');r.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');r.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS');if(q.method==='OPTIONS')return r.sendStatus(204);n()});
app.use(express.json({verify:(q,r,b)=>{q.raw=b.toString()}}));app.use(express.static('public'));app.use('/uploads',express.static('uploads'));
const stg=multer.diskStorage({destination:'uploads',filename:(q,f,cb)=>cb(null,crypto.randomBytes(12).toString('hex')+path.extname(f.originalname).slice(0,8))});
const memUp=multer({storage:multer.memoryStorage(),limits:{fileSize:10e6}}),up=multer({storage:stg,limits:{fileSize:50e6}}),imgUp=multer({storage:stg,limits:{fileSize:5e6},fileFilter:(q,f,cb)=>cb(null,/^image\//.test(f.mimetype))});
const A=fn=>(q,r)=>{try{fn(q,r)}catch(e){if(e&&e.http)return r.status(e.http).json({error:e.msg});console.error(e);r.status(500).json({error:'خطای سرور'})}};
const auth=(q,r,n)=>{let u;try{u=db.prepare('SELECT * FROM users WHERE id=?').get(jwt.verify((q.headers.authorization||'').slice(7),SECRET).id)}catch{}
 if(!u)return r.status(401).json({error:'نیاز به ورود'});q.u=u;
 if(u.banned||u.frozen){const s=SUPPORT(),p=q.path,sc=s&&s!==u.id?dm(u.id,s):0;
  const ok=(q.method==='GET'&&(p==='/api/me'||p==='/api/chats'))||p==='/api/support'||(sc&&new RegExp('^/api/chats/'+sc+'/(messages|read)$').test(p));
  if(!ok)return r.status(403).json({error:'حساب شما محدود شده است؛ فقط می‌توانید به پشتیبانی پیام دهید',restricted:1})}
 n()};
const adminOnly=(q,r,n)=>q.u.is_admin?n():r.status(403).json({error:'دسترسی ندارید'});
const isPrem=u=>(u.premium_until||0)>Date.now();
const pub=u=>{const p=isPrem(u)&&!u.hide_prem;return{id:u.id,username:u.username,first:u.first,last:u.last,avatar:u.avatar,bio:isPrem(u)?u.bio:'',verified:u.hide_verified?0:u.verified,scam:u.scam,seller:u.hide_seller?0:u.seller,prem:p?1:0,pbadge:p?(u.pbadge||'star'):null,logo:p?u.logo:null,hours:isPrem(u)?u.hours:null}};
const me=u=>({...pub(u),verified:u.verified,seller:u.seller,prem:isPrem(u)?1:0,pbadge:u.pbadge||'star',logo:u.logo,bio:u.bio,hours:u.hours,premium_until:u.premium_until||0,hide_verified:u.hide_verified||0,hide_prem:u.hide_prem||0,hide_seller:u.hide_seller||0,allow_dm:u.allow_dm===0?0:1,balance:u.balance||0,banned:u.banned||0,frozen:u.frozen||0,email:u.email,allow_calls:u.allow_calls,allow_add:u.allow_add,is_admin:u.is_admin});
const shopOf=id=>db.prepare("SELECT id,name,chat_id,status FROM shops WHERE user_id=? AND status IN('approved','pending') ORDER BY id DESC").get(id)||null;
const isMember=(c,u)=>db.prepare('SELECT 1 FROM members WHERE chat_id=? AND user_id=?').get(c,u);
const addMember=(c,u)=>db.prepare('INSERT OR IGNORE INTO members(chat_id,user_id) VALUES(?,?)').run(c,u);
const MSG=()=>`SELECT m.*,u.username,u.first,u.last,(u.verified AND NOT COALESCE(u.hide_verified,0)) verified,u.scam,(u.seller AND NOT COALESCE(u.hide_seller,0)) seller,u.pbadge,(u.premium_until>${Date.now()} AND NOT COALESCE(u.hide_prem,0)) prem,CASE WHEN COALESCE(u.hide_prem,0) THEN NULL ELSE u.logo END logo,(SELECT text FROM messages WHERE id=m.reply_to) rtext,(SELECT kind FROM messages WHERE id=m.reply_to) rkind,(SELECT COALESCE(NULLIF(TRIM(x.first||' '||x.last),''),x.username) FROM messages rm JOIN users x ON x.id=rm.user_id WHERE rm.id=m.reply_to) rname FROM messages m LEFT JOIN users u ON u.id=m.user_id`;
function sendMsg(chat,uid,text,kind='text',file=null,fname=null,reply=null,cid=null){
 const id=db.prepare('INSERT INTO messages(chat_id,user_id,text,kind,file,fname,ts,reply_to) VALUES(?,?,?,?,?,?,?,?)').run(chat,uid,text,kind,file,fname,Date.now(),reply).lastInsertRowid;
 if(uid)db.prepare('UPDATE members SET last_read=? WHERE chat_id=? AND user_id=?').run(id,chat,uid);
 const m=db.prepare(MSG()+' WHERE m.id=?').get(id);m.cid=cid;db.prepare('SELECT user_id FROM members WHERE chat_id=?').all(chat).forEach(x=>io.to('u'+x.user_id).emit('msg',m));return m}
function dm(a,b){const x=db.prepare(`SELECT c.id FROM chats c WHERE c.type='dm' AND EXISTS(SELECT 1 FROM members WHERE chat_id=c.id AND user_id=?) AND EXISTS(SELECT 1 FROM members WHERE chat_id=c.id AND user_id=?)`).get(a,b);if(x)return x.id;
 const id=db.prepare("INSERT INTO chats(type) VALUES('dm')").run().lastInsertRowid;addMember(id,a);if(b!==a)addMember(id,b);return id}
const saved=u=>{const c=db.prepare("SELECT c.id FROM chats c JOIN members m ON m.chat_id=c.id WHERE c.type='saved' AND m.user_id=?").get(u);if(c)return c.id;const id=db.prepare("INSERT INTO chats(type,title) VALUES('saved','پیام‌های ذخیره‌شده')").run().lastInsertRowid;addMember(id,u);return id};
const token=u=>jwt.sign({id:u.id},SECRET,{expiresIn:'60d'});
const inv=()=>crypto.randomBytes(6).toString('hex');
function rowFor(c,u){
 if(c.type==='dm'){const o=db.prepare('SELECT x.* FROM users x JOIN members m ON m.user_id=x.id WHERE m.chat_id=? AND x.id!=?').get(c.id,u.id)||u;c.other=pub(o);c.title=(o.first+' '+o.last).trim()||o.username;c.avatar=o.avatar;c.verified=o.verified;c.scam=o.scam;c.seller=o.seller;c.prem=c.other.prem;c.pbadge=c.other.pbadge;c.logo=c.other.logo}
 c.last=db.prepare('SELECT text,kind,ts FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT 1').get(c.id);
 c.unread=db.prepare('SELECT COUNT(*) n FROM messages WHERE chat_id=? AND id>? AND user_id!=?').get(c.id,c.last_read||0,u.id).n;
 c.can_post=!c.banned&&(c.type!=='channel'||c.owner===u.id||!!u.is_admin);c.can_edit=['group','channel'].includes(c.type)&&(c.owner===u.id||!!u.is_admin);delete c.invite;return c}
const listChats=u=>db.prepare('SELECT c.*,m.last_read FROM chats c JOIN members m ON m.chat_id=c.id WHERE m.user_id=? AND c.is_public=0').all(u.id).map(c=>rowFor(c,u)).sort((a,b)=>(b.last?b.last.ts:0)-(a.last?a.last.ts:0));
function createChat(u,type,title,priv){
 if(!u.is_admin){const mine=db.prepare("SELECT type FROM chats WHERE owner=? AND type IN('group','channel')").all(u.id);
  if(isPrem(u)){if(mine.length>=10)throw{http:403,msg:'حداکثر ۱۰ کانال و گروه می‌توانید داشته باشید'}}
  else if(mine.some(x=>x.type===type))throw{http:403,msg:`کاربر عادی فقط یک ${type==='group'?'گروه':'کانال'} می‌تواند بسازد. برای بیشتر، پریمیوم بگیرید`}}
 const id=db.prepare('INSERT INTO chats(type,title,owner,private,invite) VALUES(?,?,?,?,?)').run(type,String(title).slice(0,60),u.id,priv?1:0,inv()).lastInsertRowid;addMember(id,u.id);return id}
const kicked=(c,u)=>db.prepare('SELECT 1 FROM kicks WHERE chat_id=? AND user_id=?').get(c,u);
const find=b=>{if(b.user_id)return db.prepare('SELECT * FROM users WHERE id=?').get(b.user_id);const v=String(b.username||b.email||'').trim().toLowerCase().replace(/^@/,'');return db.prepare('SELECT * FROM users WHERE username=? OR email=?').get(v,v)||db.prepare("SELECT u.* FROM users u JOIN handles h ON h.owner_id=u.id AND h.kind='user' WHERE h.handle=?").get(v)};

app.post('/api/register',A(async(q,r)=>{
 const{email='',username='',password='',password2=''}=q.body;const un=username.trim().toLowerCase();
 if(!/^\S+@\S+\.\S+$/.test(email))return r.status(400).json({error:'ایمیل نامعتبر است'});
 if(!/^[a-z0-9_]{3,20}$/.test(un))return r.status(400).json({error:'یوزرنیم: ۳ تا ۲۰ حرف انگلیسی، عدد یا _'});
 if(password.length<6)return r.status(400).json({error:'رمز حداقل ۶ کاراکتر باشد'});
 if(password!==password2)return r.status(400).json({error:'رمز و تکرار آن یکسان نیست'});
 if(db.prepare('SELECT 1 FROM users WHERE username=? OR email=?').get(un,email.toLowerCase()))return r.status(400).json({error:'یوزرنیم یا ایمیل قبلاً ثبت شده'});
 const first=!db.prepare('SELECT 1 FROM users').get(),need=get('email_verify')==='1'&&!first,vt=crypto.randomBytes(16).toString('hex');
 const id=db.prepare('INSERT INTO users(username,email,pass,email_ok,vtoken,is_admin,verified) VALUES(?,?,?,?,?,?,?)').run(un,email.toLowerCase(),bcrypt.hashSync(password,10),need?0:1,vt,first?1:0,first?1:0).lastInsertRowid;
 addMember(OFFICIAL(),id);addMember(PUBLIC(),id);saved(id);
 const adm=db.prepare('SELECT id FROM users WHERE is_admin=1').get();
 if(adm&&adm.id!==id){const c=dm(adm.id,id);sendMsg(c,adm.id,'سلام! به سوریانوی خوش آمدید. اگر سوالی داشتید همین‌جا بپرسید.')}
 if(first)sendMsg(OFFICIAL(),id,'به سوریانوی خوش آمدید');
 if(need){const link=`${q.protocol}://${q.get('host')}/api/verify?t=${vt}`;
  if(mailer)mailer.sendMail({from:E.SMTP_FROM,to:email,subject:'تایید ایمیل سوریانوی',html:`<div dir="rtl">برای فعال‌سازی حساب روی لینک زیر بزنید:<br><a href="${link}">${link}</a></div>`}).catch(e=>console.error('mail',e.message));
  else console.log('VERIFY LINK:',link);
  return r.json({need_verify:true})}
 r.json({token:token({id})})}));
app.get('/api/verify',A((q,r)=>{const x=db.prepare('UPDATE users SET email_ok=1 WHERE vtoken=?').run(q.query.t||'-');r.redirect('/?verified='+(x.changes?1:0))}));
app.post('/api/login',A((q,r)=>{const v=(q.body.username||'').trim().toLowerCase();const u=db.prepare('SELECT * FROM users WHERE username=? OR email=?').get(v,v);
 if(!u||!bcrypt.compareSync(q.body.password||'',u.pass))return r.status(400).json({error:'یوزرنیم یا رمز اشتباه است'});
  if(!u.email_ok)return r.status(403).json({error:'ابتدا ایمیل خود را تایید کنید'});r.json({token:token(u)})}));
app.get('/api/me',auth,(q,r)=>r.json({...me(q.u),shop:shopOf(q.u.id),aliases:db.prepare("SELECT handle FROM handles WHERE kind='user' AND owner_id=?").all(q.u.id).map(x=>x.handle)}));
app.put('/api/me',auth,A((q,r)=>{const b=q.body,u=q.u,pr=isPrem(u),EMO=/\p{Extended_Pictographic}/u;let un=u.username;
 if(b.username!==undefined){un=String(b.username).trim().toLowerCase();if(!/^[a-z0-9_]{3,20}$/.test(un))return r.status(400).json({error:'یوزرنیم: ۳ تا ۲۰ حرف انگلیسی، عدد یا _'});if(un!==u.username&&taken(un))return r.status(400).json({error:'این یوزرنیم گرفته شده'})}
 const f=(k,d,n)=>b[k]===undefined?d:String(b[k]).slice(0,n),fl=(k,d)=>b[k]===undefined?d:(b[k]?1:0),first=f('first',u.first,40),last=f('last',u.last,40);
 if(!pr&&(EMO.test(first)||EMO.test(last)))return r.status(400).json({error:'گذاشتن ایموجی کنار اسم فقط برای پریمیوم است'});
 if(!pr&&((b.bio&&b.bio!==u.bio)||(b.hours&&b.hours!==u.hours)))return r.status(400).json({error:'بیوگرافی و ساعات کاری فقط برای پریمیوم است'});
 const pb=pr&&['star','tag','red'].includes(b.pbadge)?b.pbadge:(u.pbadge||'star');
 db.prepare('UPDATE users SET username=?,first=?,last=?,bio=?,hours=?,pbadge=?,allow_calls=?,allow_add=?,hide_verified=?,hide_prem=?,hide_seller=?,allow_dm=? WHERE id=?').run(un,first,last,pr?f('bio',u.bio||'',160):(u.bio||''),pr?f('hours',u.hours||'',20):(u.hours||''),pb,fl('allow_calls',u.allow_calls),fl('allow_add',u.allow_add),fl('hide_verified',u.hide_verified||0),fl('hide_prem',u.hide_prem||0),fl('hide_seller',u.hide_seller||0),fl('allow_dm',u.allow_dm===0?0:1),u.id);r.json({ok:1})}));
app.post('/api/me/avatar',auth,imgUp.single('file'),A((q,r)=>{if(!q.file)return r.status(400).json({error:'فایل عکس معتبر نیست'});db.prepare('UPDATE users SET avatar=? WHERE id=?').run('/uploads/'+q.file.filename,q.u.id);r.json({ok:1})}));

const canEdit=(id,u)=>{const c=db.prepare("SELECT * FROM chats WHERE id=? AND type IN('group','channel')").get(id);return c&&(c.owner===u.id||u.is_admin)?c:null};
app.get('/api/chats',auth,(q,r)=>{let l=listChats(q.u);if(q.u.banned||q.u.frozen){const s=SUPPORT();l=l.filter(c=>c.type==='dm'&&c.other&&c.other.id===s)}r.json(l)});
app.post('/api/chats',auth,A((q,r)=>{const{type,title,members=[]}=q.body;
 if(!['group','channel'].includes(type)||!title)return r.status(400).json({error:'اطلاعات ناقص'});
 const id=createChat(q.u,type,title,q.body.private);
 members.forEach(x=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(x);if(u&&u.allow_add)addMember(id,u.id)});r.json({id})}));
app.put('/api/chats/:id',auth,A((q,r)=>{const c=canEdit(q.params.id,q.u);if(!c)return r.status(403).json({error:'دسترسی ندارید'});
 const t=q.body.title===undefined?c.title:String(q.body.title).trim().slice(0,60)||c.title;let h=c.handle;
 if(q.body.handle!==undefined){h=String(q.body.handle).trim().toLowerCase().replace(/^@/,'');
  if(h==='')h=null;else{
   if(!/^[a-z][a-z0-9_]{3,31}$/.test(h))return r.status(400).json({error:'یوزرنیم: ۴ تا ۳۲ حرف انگلیسی، عدد یا _ و با حرف شروع شود'});
   if(taken(h,c.id))return r.status(400).json({error:'این یوزرنیم گرفته شده'});
   if(!q.u.is_admin&&!isPrem(q.u))return r.status(403).json({error:'یوزرنیم برای کانال و گروه فقط با پریمیوم ممکن است'});}}
 db.prepare('UPDATE chats SET title=?,private=?,handle=? WHERE id=?').run(t,q.body.private===undefined?c.private:(q.body.private&&!c.official&&!c.is_public?1:0),h,c.id);r.json({ok:1})}));
app.post('/api/chats/:id/avatar',auth,imgUp.single('file'),A((q,r)=>{const c=canEdit(q.params.id,q.u);if(!c||!q.file)return r.status(403).json({error:'دسترسی ندارید'});db.prepare('UPDATE chats SET avatar=? WHERE id=?').run('/uploads/'+q.file.filename,c.id);r.json({ok:1})}));
app.get('/api/chats/:id/info',auth,A((q,r)=>{if(!isMember(q.params.id,q.u.id))return r.status(403).json({error:'عضو نیستید'});const c=db.prepare('SELECT * FROM chats WHERE id=?').get(q.params.id);const ed=!!canEdit(c.id,q.u);
 r.json({members:db.prepare('SELECT u.* FROM users u JOIN members m ON m.user_id=u.id WHERE m.chat_id=? LIMIT 200').all(c.id).map(pub),count:db.prepare('SELECT COUNT(*) n FROM members WHERE chat_id=?').get(c.id).n,
  private:c.private,official:c.official||c.is_public?1:0,handle:c.handle,invite:(ed||!c.private)&&!c.is_public?c.invite:null,aliases:db.prepare("SELECT handle FROM handles WHERE kind='chat' AND owner_id=?").all(c.id).map(x=>x.handle)})}));
app.post('/api/chats/:id/leave',auth,A((q,r)=>{const c=db.prepare('SELECT * FROM chats WHERE id=?').get(q.params.id);if(!c)return r.status(404).json({error:'یافت نشد'});
 if(c.official)return r.status(403).json({error:'از کانال اصلی نمی‌توانید خارج شوید'});if(c.is_public)return r.status(403).json({error:'از گپ عمومی نمی‌توانید خارج شوید'});if(!['group','channel'].includes(c.type))return r.status(400).json({error:'امکان‌پذیر نیست'});
 db.prepare('DELETE FROM members WHERE chat_id=? AND user_id=?').run(c.id,q.u.id);r.json({ok:1})}));
app.post('/api/dm',auth,A((q,r)=>{const u=find(q.body);if(!u)return r.status(404).json({error:'کاربری با این مشخصات پیدا نشد'});
 if(u.allow_dm===0&&!q.u.is_admin&&u.id!==q.u.id&&u.id!==SUPPORT())return r.status(403).json({error:'این کاربر پیام خصوصی را غیرفعال کرده است'});r.json({id:dm(q.u.id,u.id)})}));
app.post('/api/chats/:id/join',auth,A((q,r)=>{const c=db.prepare('SELECT * FROM chats WHERE id=?').get(q.params.id);if(!c||!['group','channel'].includes(c.type)||c.private||c.banned)return r.status(404).json({error:'یافت نشد'});if(kicked(c.id,q.u.id))return r.status(403).json({error:'شما از این گفتگو حذف شده‌اید'});addMember(c.id,q.u.id);r.json({ok:1})}));
app.post('/api/invite/:code',auth,A((q,r)=>{const c=db.prepare('SELECT * FROM chats WHERE invite=?').get(q.params.code);if(!c||c.banned)return r.status(404).json({error:'لینک دعوت معتبر نیست'});if(kicked(c.id,q.u.id))return r.status(403).json({error:'شما از این گفتگو حذف شده‌اید'});addMember(c.id,q.u.id);r.json({id:c.id})}));
app.post('/api/chats/:id/add',auth,A((q,r)=>{const c=db.prepare('SELECT * FROM chats WHERE id=?').get(q.params.id);
 if(!c||!isMember(c.id,q.u.id))return r.status(403).json({error:'دسترسی ندارید'});const u=find(q.body);
 if(!u)return r.status(404).json({error:'کاربر یافت نشد'});if(!u.allow_add)return r.status(403).json({error:'این کاربر اجازه افزودن به گروه را نداده است'});addMember(c.id,u.id);r.json({ok:1})}));
app.get('/api/chats/:id/messages',auth,A((q,r)=>{if(!isMember(q.params.id,q.u.id))return r.status(403).json({error:'عضو نیستید'});
 r.json({messages:db.prepare(MSG()+' WHERE chat_id=? ORDER BY m.id DESC LIMIT 200').all(q.params.id).reverse(),read:db.prepare('SELECT COALESCE(MAX(last_read),0) r FROM members WHERE chat_id=? AND user_id!=?').get(q.params.id,q.u.id).r})}));
app.post('/api/chats/:id/read',auth,A((q,r)=>{if(!isMember(q.params.id,q.u.id))return r.json({});const l=db.prepare('SELECT COALESCE(MAX(id),0) l FROM messages WHERE chat_id=?').get(q.params.id).l;
 db.prepare('UPDATE members SET last_read=? WHERE chat_id=? AND user_id=? AND last_read<?').run(l,q.params.id,q.u.id,l);
 db.prepare('SELECT user_id FROM members WHERE chat_id=? AND user_id!=?').all(q.params.id,q.u.id).forEach(x=>io.to('u'+x.user_id).emit('read',{chat_id:+q.params.id,user_id:q.u.id,last:l}));r.json({ok:1})}));
function runCmd(q,c,text){const t=text.trim().split(/\s+/),cmd=t[0].slice(1).toLowerCase();
 if(!['ban','unban','freeze','unfreeze','give','mute','unmute','sick','tick','untick','seller','unseller','prem','unprem'].includes(cmd))return null;
 const adm=!!q.u.is_admin,own=c.owner===q.u.id&&!c.is_public&&!c.official;
 if(!(['mute','unmute','sick'].includes(cmd)?(adm||own):adm))return{error:'شما اجازه‌ی این دستور را ندارید'};
 let tu=null,num=null;t.slice(1).forEach(x=>{if(x.startsWith('@'))tu=db.prepare('SELECT * FROM users WHERE username=?').get(x.slice(1).toLowerCase());else if(/^\d+(\.\d+)?$/.test(x))num=+x});
 if(!tu&&q.body.reply_to){const rm=db.prepare('SELECT user_id FROM messages WHERE id=? AND chat_id=?').get(q.body.reply_to,c.id);if(rm&&rm.user_id)tu=db.prepare('SELECT * FROM users WHERE id=?').get(rm.user_id)}
 if(!tu)return{error:'کاربر مشخص نشد؛ روی پیامش ریپلای کنید یا @یوزرنیم بنویسید'};
 if(['ban','mute','sick','freeze'].includes(cmd)&&(tu.is_admin||tu.id===q.u.id))return{error:'این دستور روی این کاربر قابل اجرا نیست'};
 const sys=x=>sendMsg(c.id,null,x,'sys'),n='@'+tu.username;
 if(cmd==='ban'){db.prepare('UPDATE users SET banned=1 WHERE id=?').run(tu.id);sys(n+' مسدود شد');return{msg:'کاربر مسدود شد'}}
 if(cmd==='unban'){db.prepare('UPDATE users SET banned=0 WHERE id=?').run(tu.id);return{msg:'مسدودیت برداشته شد'}}
 if(cmd==='mute'){db.prepare('INSERT OR REPLACE INTO mutes VALUES(?,?,?)').run(c.id,tu.id,num?Date.now()+num*36e5:0);sys(n+(num?` به مدت ${num} ساعت بی‌صدا شد`:' بی‌صدا شد'));return{msg:'انجام شد'}}
 if(cmd==='unmute'){db.prepare('DELETE FROM mutes WHERE chat_id=? AND user_id=?').run(c.id,tu.id);sys(n+' دوباره می‌تواند صحبت کند');return{msg:'انجام شد'}}
 if(cmd==='sick'){if(c.official)return{error:'از کانال اصلی نمی‌شود حذف کرد'};db.prepare('DELETE FROM members WHERE chat_id=? AND user_id=?').run(c.id,tu.id);db.prepare('INSERT OR IGNORE INTO kicks VALUES(?,?)').run(c.id,tu.id);io.to('u'+tu.id).emit('kick',{chat_id:c.id});sys(n+' از گفتگو حذف شد');return{msg:'کاربر حذف شد'}}
 if(cmd==='tick'||cmd==='untick'){db.prepare('UPDATE users SET verified=? WHERE id=?').run(cmd==='tick'?1:0,tu.id);return{msg:cmd==='tick'?'تیک آبی داده شد':'تیک آبی گرفته شد'}}
 if(cmd==='seller'||cmd==='unseller'){db.prepare('UPDATE users SET seller=? WHERE id=?').run(cmd==='seller'?1:0,tu.id);if(cmd==='seller')db.prepare("UPDATE shops SET status='approved' WHERE user_id=? AND status='pending'").run(tu.id);return{msg:cmd==='seller'?'فروشنده شد':'فروشندگی برداشته شد'}}
 if(cmd==='freeze'||cmd==='unfreeze'){db.prepare('UPDATE users SET frozen=? WHERE id=?').run(cmd==='freeze'?1:0,tu.id);return{msg:cmd==='freeze'?'کاربر فریز شد':'فریز برداشته شد'}}
 if(cmd==='give'){if(!num)return{error:'مقدار را بنویسید، مثلا /give 5'};bal(tu.id,num,'admin','هدیه مدیریت');return{msg:num+' سوریا استار داده شد'}}
 if(cmd==='prem'){const m=num||1;db.prepare('UPDATE users SET premium_until=? WHERE id=?').run(Math.max(Date.now(),tu.premium_until||0)+m*30*864e5,tu.id);return{msg:`پریمیوم ${m} ماهه فعال شد`}}
 db.prepare('UPDATE users SET premium_until=0 WHERE id=?').run(tu.id);return{msg:'پریمیوم برداشته شد'}}
app.post('/api/chats/:id/messages',auth,up.single('file'),A((q,r)=>{const c=db.prepare('SELECT * FROM chats WHERE id=?').get(q.params.id);
 if(!c||!isMember(c.id,q.u.id))return r.status(403).json({error:'عضو نیستید'});if(c.banned)return r.status(403).json({error:'این گفتگو مسدود شده است'});
 if(c.type==='channel'&&c.owner!==q.u.id&&!q.u.is_admin)return r.status(403).json({error:'فقط مدیر کانال می‌تواند پیام بگذارد'});
 if(!q.u.is_admin){const mu=db.prepare('SELECT until FROM mutes WHERE chat_id=? AND user_id=?').get(c.id,q.u.id);if(mu&&(mu.until===0||mu.until>Date.now()))return r.status(403).json({error:'شما در این گفتگو بی‌صدا شده‌اید'})}
 const txt=String(q.body.text||'').slice(0,4000);
 if(!q.u.is_admin&&!isPrem(q.u)&&(txt.match(/:([a-z_]+):/g)||[]).some(x=>PREM_EMO.has(x.slice(1,-1))))return r.status(403).json({error:'ایموجی‌های ویژه مخصوص پریمیوم است'});
 if(c.type==='dm'&&!q.u.is_admin){const o=db.prepare('SELECT u.* FROM users u JOIN members m ON m.user_id=u.id WHERE m.chat_id=? AND u.id!=?').get(c.id,q.u.id);if(o&&o.allow_dm===0&&o.id!==SUPPORT())return r.status(403).json({error:'این کاربر پیام خصوصی را غیرفعال کرده است'})}
 if(!q.file&&txt.startsWith('/')){const x=runCmd(q,c,txt);if(x)return x.error?r.status(403).json({error:x.error}):r.json({cmd:true,msg:x.msg})}
 let kind='text',f=null,fn=null;if(q.file){f='/uploads/'+q.file.filename;fn=Buffer.from(q.file.originalname,'latin1').toString('utf8');const m=q.file.mimetype;kind=m.startsWith('image/')?'image':m.startsWith('video/')?'video':m.startsWith('audio/')?'voice':'file'}
 if(!txt.trim()&&!f)return r.status(400).json({error:'پیام خالی است'});
 const rp=+q.body.reply_to||null;const okr=rp&&db.prepare('SELECT 1 FROM messages WHERE id=? AND chat_id=?').get(rp,c.id);
 r.json(sendMsg(c.id,q.u.id,txt,kind,f,fn,okr?rp:null,String(q.body.cid||'').slice(0,40)||null))}));
app.get('/api/public',auth,A((q,r)=>{const id=PUBLIC();if(kicked(id,q.u.id))return r.status(403).json({error:'شما از گپ عمومی حذف شده‌اید'});addMember(id,q.u.id);
 r.json(rowFor(db.prepare('SELECT c.*,m.last_read FROM chats c JOIN members m ON m.chat_id=c.id WHERE c.id=? AND m.user_id=?').get(id,q.u.id),q.u))}));
app.post('/api/shops',auth,A((q,r)=>{const name=String(q.body.name||'').trim().slice(0,60),descr=String(q.body.descr||'').trim().slice(0,300);if(!name)return r.status(400).json({error:'نام فروشگاه را بنویسید'});
 if(db.prepare("SELECT 1 FROM shops WHERE user_id=? AND status IN('pending','approved')").get(q.u.id))return r.status(400).json({error:'شما یک فروشگاه ثبت‌شده یا در انتظار تایید دارید'});
 let cid=+q.body.chat_id||0;if(cid){if(!db.prepare("SELECT 1 FROM chats WHERE id=? AND owner=? AND type='channel'").get(cid,q.u.id))return r.status(400).json({error:'کانال معتبر نیست'})}else cid=createChat(q.u,'channel',name,0);
 db.prepare("INSERT INTO shops(user_id,name,descr,chat_id,status,ts) VALUES(?,?,?,?,'pending',?)").run(q.u.id,name,descr,cid,Date.now());r.json({ok:1})}));
app.get('/api/shops',auth,A((q,r)=>r.json(db.prepare("SELECT s.id,s.user_id uid,s.name,s.descr,s.chat_id,c.title,c.avatar,c.handle,u.username,u.verified,u.premium_until,u.pbadge FROM shops s JOIN chats c ON c.id=s.chat_id JOIN users u ON u.id=s.user_id WHERE s.status='approved' AND c.banned=0 AND u.banned=0 ORDER BY s.id DESC LIMIT 100").all().map(x=>({...x,prem:isPrem(x)?1:0})))));
app.post('/api/shops/:id/open',auth,A((q,r)=>{const s=db.prepare("SELECT * FROM shops WHERE id=? AND status='approved'").get(q.params.id);if(!s)return r.status(404).json({error:'یافت نشد'});if(kicked(s.chat_id,q.u.id))return r.status(403).json({error:'شما از این کانال حذف شده‌اید'});addMember(s.chat_id,q.u.id);r.json({id:s.chat_id})}));
app.get('/api/search',auth,A((q,r)=>{const s='%'+String(q.query.q||'').replace(/[%_@]/g,'')+'%';
 r.json({users:db.prepare('SELECT * FROM users WHERE banned=0 AND (username LIKE ? OR first LIKE ? OR last LIKE ? OR id IN(SELECT owner_id FROM handles WHERE kind=\'user\' AND handle LIKE ?)) AND id!=? LIMIT 20').all(s,s,s,s,q.u.id).map(pub),
  chats:db.prepare("SELECT id,type,title,verified,avatar,handle FROM chats WHERE type IN('group','channel') AND private=0 AND banned=0 AND is_public=0 AND (title LIKE ? OR handle LIKE ? OR id IN(SELECT owner_id FROM handles WHERE kind='chat' AND handle LIKE ?)) LIMIT 20").all(s,s,s)})}));
app.get('/api/contacts',auth,(q,r)=>r.json(db.prepare('SELECT u.* FROM users u JOIN contacts c ON c.contact_id=u.id WHERE c.user_id=?').all(q.u.id).map(pub)));
app.post('/api/contacts',auth,A((q,r)=>{const u=find(q.body);if(!u)return r.status(404).json({error:'کاربری با این مشخصات پیدا نشد'});if(u.id===q.u.id)return r.status(400).json({error:'این خودِ شما هستید'});db.prepare('INSERT OR IGNORE INTO contacts VALUES(?,?)').run(q.u.id,u.id);r.json(pub(u))}));
app.get('/api/user/:id',auth,A((q,r)=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(q.params.id);if(!u)return r.status(404).json({});
 r.json({...pub(u),allow_calls:u.allow_calls,shop:db.prepare("SELECT id,name,chat_id FROM shops WHERE user_id=? AND status='approved'").get(u.id)||null})}));


const hv=h=>String(h||'').trim().toLowerCase().replace(/^@/,''),HRE=/^[a-z][a-z0-9_]{3,31}$/;
function addAlias(q,r,kind,owner,count){if(!q.u.is_admin&&!isPrem(q.u))return r.status(403).json({error:'یوزرنیم اضافه فقط برای پریمیوم است'});const h=hv(q.body.handle);
 if(!HRE.test(h))return r.status(400).json({error:'یوزرنیم: ۴ تا ۳۲ حرف انگلیسی، عدد یا _ و با حرف شروع شود'});if(taken(h))return r.status(400).json({error:'این یوزرنیم گرفته شده'});
 if(!q.u.is_admin&&db.prepare('SELECT COUNT(*) n FROM handles WHERE kind=? AND owner_id=?').get(kind,owner).n>=4)return r.status(400).json({error:'حداکثر ۵ یوزرنیم (۱ اصلی + ۴ اضافه)'});
 db.prepare('INSERT INTO handles VALUES(?,?,?)').run(h,kind,owner);r.json({ok:1})}
app.get('/api/me/handles',auth,(q,r)=>r.json(db.prepare("SELECT handle FROM handles WHERE kind='user' AND owner_id=?").all(q.u.id).map(x=>x.handle)));
app.post('/api/me/handles',auth,A((q,r)=>addAlias(q,r,'user',q.u.id)));
app.delete('/api/me/handles/:h',auth,(q,r)=>{db.prepare("DELETE FROM handles WHERE kind='user' AND owner_id=? AND handle=?").run(q.u.id,q.params.h);r.json({ok:1})});
app.post('/api/chats/:id/handles',auth,A((q,r)=>{const c=canEdit(q.params.id,q.u);if(!c)return r.status(403).json({error:'دسترسی ندارید'});addAlias(q,r,'chat',c.id)}));
app.delete('/api/chats/:id/handles/:h',auth,A((q,r)=>{const c=canEdit(q.params.id,q.u);if(!c)return r.status(403).json({error:'دسترسی ندارید'});db.prepare("DELETE FROM handles WHERE kind='chat' AND owner_id=? AND handle=?").run(c.id,q.params.h);r.json({ok:1})}));
app.post('/api/me/logo',auth,imgUp.single('file'),A((q,r)=>{if(!isPrem(q.u)&&!q.u.is_admin)return r.status(403).json({error:'لوگوی کنار نام فقط برای پریمیوم است'});if(!q.file)return r.status(400).json({error:'فایل عکس معتبر نیست'});db.prepare('UPDATE users SET logo=? WHERE id=?').run('/uploads/'+q.file.filename,q.u.id);r.json({ok:1})}));
app.delete('/api/me/logo',auth,(q,r)=>{db.prepare('UPDATE users SET logo=NULL WHERE id=?').run(q.u.id);r.json({ok:1})});
app.get('/api/support',auth,A((q,r)=>{const s=SUPPORT();if(!s)return r.status(404).json({error:'پشتیبانی تنظیم نشده'});if(s===q.u.id)return r.status(400).json({error:'شما خودِ پشتیبانی هستید'});
 const id=dm(q.u.id,s);r.json(rowFor(db.prepare('SELECT c.*,m.last_read FROM chats c JOIN members m ON m.chat_id=c.id WHERE c.id=? AND m.user_id=?').get(id,q.u.id),q.u))}));
// ---- wallet / stars ----
app.get('/api/wallet',auth,A((q,r)=>r.json({balance:db.prepare('SELECT COALESCE(balance,0) b FROM users WHERE id=?').get(q.u.id).b,unlimited:!!q.u.is_admin,price:price(),history:db.prepare('SELECT * FROM (SELECT * FROM price_hist ORDER BY ts DESC LIMIT 40) ORDER BY ts').all(),ledger:db.prepare('SELECT amount,kind,note,ts FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 30').all(q.u.id)})));
app.get('/api/stars/quote',auth,A((q,r)=>{const n=nStars(q.query.n);r.json(q.query.side==='sell'?qSell(n):qBuy(n))}));
app.post('/api/stars/send',auth,A((q,r)=>{const n=nStars(q.body.amount),t=find(q.body);if(!t)return r.status(404).json({error:'کاربر یافت نشد'});if(t.id===q.u.id)return r.status(400).json({error:'به خودتان نمی‌توانید بفرستید'});
 spend(q.u,n,'send','به @'+t.username);bal(t.id,n,'recv','از @'+q.u.username);r.json({ok:1})}));
app.post('/api/stars/sell',auth,A((q,r)=>{const n=nStars(q.body.n),card=String(q.body.card||'').replace(/\D/g,''),holder=String(q.body.holder||'').trim().slice(0,60);
 if(card.length!==16||!holder)return r.status(400).json({error:'شماره کارت ۱۶ رقمی و نام صاحب کارت را بنویسید'});const x=qSell(n);spend(q.u,n,'sell','درخواست برداشت');setPrice(x.newP);
 db.prepare('INSERT INTO cashouts(user_id,stars,toman,card,holder,status,ts) VALUES(?,?,?,?,?,?,?)').run(q.u.id,n,x.pay,card,holder,'pending',Date.now());r.json({toman:x.pay})}));
const tpCfg=()=>({base:(get('pay_base')||'https://tonpays.online').replace(/\/$/,''),key:get('pay_key')||'',mode:get('pay_mode')||'normal',secret:get('pay_secret')||'',origin:(get('pay_origin')||'').replace(/\/$/,'')});
async function tpCreate(d,u,q){const c=tpCfg();if(!c.key)throw{http:503,msg:'درگاه پرداخت هنوز تنظیم نشده است'};const origin=c.origin||`${q.protocol}://${q.get('host')}`,cb=origin+'/api/pay/webhook',order='D'+d.id;
 const call=async(path,body)=>{const x=await fetch(c.base+path,{method:'POST',headers:{'Content-Type':'application/json','X-API-Key':c.key},body:JSON.stringify(body)});const j=await x.json().catch(()=>({}));if(!x.ok)throw{http:502,msg:(j.detail&&(j.detail.message||j.detail.code))||'خطا از درگاه پرداخت'};return j};
 if(c.mode==='custom'){const j=await call('/api/custom/v1/invoices/web/create',{amount:d.toman,order_id:order,buyer_username:u.username,callback_url:cb});
  const vr=await fetch(c.base+'/api/custom/v1/invoices/view?token='+encodeURIComponent(j.view_token),{headers:{Origin:origin}});const v=await vr.json().catch(()=>({}));
  if(!vr.ok)throw{http:502,msg:'نمایش کارت ناموفق بود؛ دامنه سایت را در پنل درگاه تایید کنید'};
  return{invoice_id:j.invoice_id,card:v.card_number,holder:v.card_holder||v.name_card||v.holder_card||'',token:j.view_token,final:j.final_amount}}
 const j=await call('/api/v1/invoices/create',{amount:d.toman,order_id:order,callback_url:cb});return{invoice_id:j.invoice_id,pay_url:j.web_invoice_url||j.invoice_url,final:j.final_amount}}
function creditDep(id){db.transaction(()=>{const d=db.prepare('SELECT * FROM deposits WHERE id=?').get(id);if(!d||d.status!=='pending')return;db.prepare("UPDATE deposits SET status='completed' WHERE id=?").run(id);bal(d.user_id,d.stars,'deposit','شارژ');setPrice(price()*(1+sget('star_k',.002)*d.stars))})()}
async function tpConfirm(d){const c=tpCfg();if(!d.invoice_id||!c.key)return;const x=await fetch(c.base+(d.mode==='custom'?'/api/custom/v1':'/api/v1')+'/invoices/check/'+d.invoice_id,{headers:{'X-API-Key':c.key}});const j=await x.json().catch(()=>({}));
 if(x.ok&&j.paid&&j.status==='completed')creditDep(d.id);else if(x.ok&&['rejected','expired','canceled'].includes(j.status))db.prepare("UPDATE deposits SET status='failed' WHERE id=? AND status='pending'").run(d.id)}
const depOut=d=>({id:d.id,stars:d.stars,toman:d.toman,status:d.status,mode:d.mode,pay_url:d.pay_url,card:d.card,holder:d.holder});
app.post('/api/stars/buy',auth,AA(async(q,r)=>{const n=nStars(q.body.n),x=qBuy(n);if(x.cost<1000)throw{http:400,msg:'مبلغ خیلی کم است'};
 const id=db.prepare("INSERT INTO deposits(user_id,stars,toman,mode,status,ts) VALUES(?,?,?,?,'pending',?)").run(q.u.id,n,x.cost,tpCfg().mode,Date.now()).lastInsertRowid,d=db.prepare('SELECT * FROM deposits WHERE id=?').get(id);
 try{const g=await tpCreate(d,q.u,q);db.prepare('UPDATE deposits SET invoice_id=?,pay_url=?,card=?,holder=?,view_token=?,toman=? WHERE id=?').run(g.invoice_id,g.pay_url||null,g.card||null,g.holder||null,g.token||null,g.final||x.cost,id)}
 catch(e){db.prepare("UPDATE deposits SET status='failed' WHERE id=?").run(id);throw e}r.json(depOut(db.prepare('SELECT * FROM deposits WHERE id=?').get(id)))}));
app.get('/api/stars/deposits/:id',auth,AA(async(q,r)=>{const d=db.prepare('SELECT * FROM deposits WHERE id=? AND user_id=?').get(q.params.id,q.u.id);if(!d)throw{http:404,msg:'یافت نشد'};if(d.status==='pending')await tpConfirm(d);r.json(depOut(db.prepare('SELECT * FROM deposits WHERE id=?').get(d.id)))}));
app.post('/api/stars/deposits/:id/receipt',auth,memUp.single('file'),AA(async(q,r)=>{const d=db.prepare('SELECT * FROM deposits WHERE id=? AND user_id=?').get(q.params.id,q.u.id);if(!d||!q.file||d.mode!=='custom')throw{http:400,msg:'درخواست نامعتبر'};const c=tpCfg(),fd=new FormData();
 fd.append('file',new Blob([q.file.buffer],{type:q.file.mimetype}),q.file.originalname||'receipt.jpg');const x=await fetch(c.base+'/api/custom/v1/invoices/'+d.invoice_id+'/receipt',{method:'POST',headers:{'X-API-Key':c.key},body:fd});const j=await x.json().catch(()=>({}));
 if(!x.ok)throw{http:502,msg:(j.detail&&(j.detail.message||j.detail.code))||'ارسال رسید ناموفق بود'};r.json({ok:1})}));
app.post('/api/pay/webhook',AA(async(q,r)=>{const c=tpCfg();if(c.secret){const sig=String(q.get('X-TonPays-Signature')||''),t=(sig.match(/t=(\d+)/)||[])[1],v=(sig.match(/v1=([a-f0-9]+)/)||[])[1],h=t&&crypto.createHmac('sha256',c.secret).update(t+'.'+(q.raw||'')).digest('hex');if(!v||v!==h)return r.status(401).json({error:'bad signature'})}
 const d=db.prepare('SELECT * FROM deposits WHERE invoice_id=?').get((q.body||{}).invoice_id);if(d&&d.status==='pending')await tpConfirm(d);r.json({ok:1})}));
// ---- plans / products / orders ----
app.get('/api/plans',auth,(q,r)=>r.json(db.prepare('SELECT id,title,days,price FROM plans WHERE active=1 ORDER BY days').all()));
app.post('/api/plans/:id/buy',auth,A((q,r)=>{const p=db.prepare('SELECT * FROM plans WHERE id=? AND active=1').get(q.params.id);if(!p)return r.status(404).json({error:'پلن یافت نشد'});
 const t=q.body.to?find({username:q.body.to}):q.u;if(!t)return r.status(404).json({error:'کاربر یافت نشد'});spend(q.u,p.price,'plan',p.title);if(!q.u.is_admin)bal(ADMINID(),p.price,'income','پلن '+p.title);
 db.prepare('UPDATE users SET premium_until=? WHERE id=?').run(Math.max(Date.now(),t.premium_until||0)+p.days*864e5,t.id);
 if(t.id!==q.u.id)sendMsg(dm(q.u.id,t.id),q.u.id,`پریمیوم ${p.days} روزه برای شما هدیه فرستاد`);r.json({ok:1,gift:t.id!==q.u.id})}));
app.get('/api/products',auth,A((q,r)=>r.json(q.query.official==='1'?db.prepare('SELECT id,title,descr,price,kind,seller_id FROM products WHERE official=1 AND active=1 ORDER BY id DESC').all():db.prepare('SELECT id,title,descr,price,kind,seller_id FROM products WHERE official=0 AND active=1 AND seller_id=? ORDER BY id DESC').all(+q.query.seller||0))));
app.post('/api/products',auth,up.single('file'),A((q,r)=>{const off=q.body.official==='1';if(off&&!q.u.is_admin)return r.status(403).json({error:'دسترسی ندارید'});if(!off&&!q.u.seller&&!q.u.is_admin)return r.status(403).json({error:'فقط فروشنده‌های تایید‌شده'});
 const title=String(q.body.title||'').trim().slice(0,80),pr=+q.body.price;if(!title||!(pr>0))return r.status(400).json({error:'نام و قیمت (سوریا استار) را بنویسید'});
 db.prepare('INSERT INTO products(seller_id,title,descr,price,kind,content,file,fname,official,ts) VALUES(?,?,?,?,?,?,?,?,?,?)').run(q.u.id,title,String(q.body.descr||'').slice(0,500),pr,q.file?'file':'text',off?String(q.body.content||'').slice(0,4000):'',off&&q.file?'/uploads/'+q.file.filename:null,off&&q.file?Buffer.from(q.file.originalname,'latin1').toString('utf8'):null,off?1:0,Date.now());r.json({ok:1})}));
app.delete('/api/products/:id',auth,A((q,r)=>{const p=db.prepare('SELECT * FROM products WHERE id=?').get(q.params.id);if(!p||(p.seller_id!==q.u.id&&!q.u.is_admin))return r.status(403).json({error:'دسترسی ندارید'});db.prepare('UPDATE products SET active=0 WHERE id=?').run(p.id);r.json({ok:1})}));
app.post('/api/products/:id/buy',auth,A((q,r)=>{const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(q.params.id);if(!p)return r.status(404).json({error:'محصول یافت نشد'});if(p.seller_id===q.u.id&&!p.official)return r.status(400).json({error:'محصول خودتان را نمی‌توانید بخرید'});
 spend(q.u,p.price,'buy',p.title);
 if(p.official){bal(ADMINID(),p.price,'income',p.title);const id=db.prepare("INSERT INTO orders(product_id,buyer_id,seller_id,price,status,dtext,dfile,dfname,ts,dts) VALUES(?,?,?,?,'completed',?,?,?,?,?)").run(p.id,q.u.id,p.seller_id,p.price,p.content,p.file,p.fname,Date.now(),Date.now()).lastInsertRowid;
  const c=dm(p.seller_id,q.u.id);sendMsg(c,p.seller_id,'محصول شما: '+p.title);if(p.content)sendMsg(c,p.seller_id,p.content);if(p.file)sendMsg(c,p.seller_id,'',kindOf(p.fname),p.file,p.fname);return r.json({order:id,delivered:true,chat:c})}
 const id=db.prepare("INSERT INTO orders(product_id,buyer_id,seller_id,price,status,ts) VALUES(?,?,?,?,'paid',?)").run(p.id,q.u.id,p.seller_id,p.price,Date.now()).lastInsertRowid;
 const c=dm(q.u.id,p.seller_id);sendMsg(c,q.u.id,`سفارش جدید #${id}: ${p.title} (${p.price} سوریا استار). پول در امانت است.`);r.json({order:id,delivered:false,chat:c})}));
app.post('/api/orders/:id/deliver',auth,up.single('file'),A((q,r)=>{const o=db.prepare('SELECT * FROM orders WHERE id=? AND seller_id=?').get(q.params.id,q.u.id);if(!o||o.status!=='paid')return r.status(400).json({error:'سفارش قابل تحویل نیست'});
 const txt=String(q.body.text||'').slice(0,4000);if(!txt&&!q.file)return r.status(400).json({error:'متن محصول را بنویسید یا فایل بفرستید'});const f=q.file?'/uploads/'+q.file.filename:null,fn=q.file?Buffer.from(q.file.originalname,'latin1').toString('utf8'):null;
 db.prepare("UPDATE orders SET status='delivered',dtext=?,dfile=?,dfname=?,dts=? WHERE id=?").run(txt,f,fn,Date.now(),o.id);const c=dm(q.u.id,o.buyer_id);if(txt)sendMsg(c,q.u.id,txt);if(f)sendMsg(c,q.u.id,'',kindOf(fn),f,fn);r.json({ok:1})}));
app.get('/api/orders',auth,A((q,r)=>r.json(db.prepare('SELECT o.id,o.price,o.status,o.ts,p.title FROM orders o JOIN products p ON p.id=o.product_id WHERE '+(q.query.role==='seller'?'o.seller_id':'o.buyer_id')+'=? ORDER BY o.id DESC LIMIT 50').all(q.u.id))));


const emitChat=(cid,ev,data)=>db.prepare('SELECT user_id FROM members WHERE chat_id=?').all(cid).forEach(x=>io.to('u'+x.user_id).emit(ev,data));
app.put('/api/messages/:id',auth,A((q,r)=>{const m=db.prepare('SELECT * FROM messages WHERE id=?').get(q.params.id);if(!m||m.user_id!==q.u.id||m.kind!=='text')return r.status(403).json({error:'امکان ویرایش نیست'});
 const t=String(q.body.text||'').slice(0,4000);if(!t.trim())return r.status(400).json({error:'پیام خالی است'});
 if(!q.u.is_admin&&!isPrem(q.u)&&(t.match(/:([a-z_]+):/g)||[]).some(x=>PREM_EMO.has(x.slice(1,-1))))return r.status(403).json({error:'ایموجی‌های ویژه مخصوص پریمیوم است'});
 db.prepare('UPDATE messages SET text=?,edited=1 WHERE id=?').run(t,m.id);emitChat(m.chat_id,'msgedit',{id:m.id,chat_id:m.chat_id,text:t});r.json({ok:1})}));
app.delete('/api/messages/:id',auth,A((q,r)=>{const m=db.prepare('SELECT * FROM messages WHERE id=?').get(q.params.id);if(!m)return r.status(404).json({error:'یافت نشد'});const c=db.prepare('SELECT * FROM chats WHERE id=?').get(m.chat_id);
 if(!(m.user_id===q.u.id||q.u.is_admin||(c.owner===q.u.id&&['group','channel'].includes(c.type)&&!c.official&&!c.is_public)))return r.status(403).json({error:'اجازه حذف ندارید'});
 db.prepare('DELETE FROM messages WHERE id=?').run(m.id);emitChat(m.chat_id,'msgdel',{id:m.id,chat_id:m.chat_id});r.json({ok:1})}));

// ---- admin ----
const AD=[auth,adminOnly],N=a=>db.prepare(a).get().n;
app.get('/api/admin/stats',AD,(q,r)=>r.json({users:N('SELECT COUNT(*) n FROM users'),chats:N("SELECT COUNT(*) n FROM chats WHERE type IN('group','channel')"),messages:N('SELECT COUNT(*) n FROM messages'),shops:N("SELECT COUNT(*) n FROM shops WHERE status='pending'"),email_verify:get('email_verify')==='1'}));
app.put('/api/admin/email_verify',AD,(q,r)=>{set('email_verify',q.body.on?1:0);r.json({ok:1})});
app.get('/api/admin/users',AD,A((q,r)=>{const s='%'+String(q.query.q||'').replace(/[%_]/g,'')+'%',f=q.query.f,w=['(username LIKE ? OR email LIKE ? OR first LIKE ? OR last LIKE ?)'];
 if(['verified','scam','banned','seller','frozen'].includes(f))w.push(f+'=1');if(f==='premium')w.push('premium_until>'+Date.now());const W=w.join(' AND '),a=[s,s,s,s];
 r.json({total:db.prepare(`SELECT COUNT(*) n FROM users WHERE ${W}`).get(...a).n,items:db.prepare(`SELECT id,username,email,first,last,avatar,bio,verified,scam,banned,is_admin,seller,premium_until,pbadge,frozen,balance,logo FROM users WHERE ${W} ORDER BY id DESC LIMIT 30 OFFSET ?`).all(...a,(+q.query.page||0)*30)})}));
app.get('/api/admin/chats',AD,A((q,r)=>{const s='%'+String(q.query.q||'').replace(/[%_]/g,'')+'%',f=q.query.f,w=["type IN('group','channel')",'title LIKE ?'],a=[s];
 if(['group','channel'].includes(f)){w.push('type=?');a.push(f)}if(['verified','scam','banned'].includes(f))w.push(f+'=1');const W=w.join(' AND ');
 r.json({total:db.prepare(`SELECT COUNT(*) n FROM chats WHERE ${W}`).get(...a).n,items:db.prepare(`SELECT id,type,title,avatar,verified,scam,banned,private,official,(SELECT COUNT(*) FROM members WHERE chat_id=chats.id) members FROM chats WHERE ${W} ORDER BY id DESC LIMIT 30 OFFSET ?`).all(...a,(+q.query.page||0)*30)})}));
const upd=t=>(q,r)=>{const sets=[],v=[];['verified','scam','banned','seller','frozen'].forEach(k=>{if(q.body[k]!==undefined){sets.push(k+'=?');v.push(q.body[k]?1:0)}});if(!sets.length)return r.json({ok:1});
 if(q.body.banned){const x=db.prepare(t==='users'?'SELECT is_admin a FROM users WHERE id=?':'SELECT official a FROM chats WHERE id=?').get(q.params.id);if(x&&x.a)return r.status(400).json({error:t==='users'?'ادمین را نمی‌توان مسدود کرد':'کانال اصلی را نمی‌توان مسدود کرد'})}
 db.prepare(`UPDATE ${t} SET ${sets.join(',')} WHERE id=?`).run(...v,q.params.id);r.json({ok:1})};
app.put('/api/admin/users/:id',AD,upd('users'));app.put('/api/admin/chats/:id',AD,upd('chats'));
app.put('/api/admin/users/:id/premium',AD,A((q,r)=>{const u=db.prepare('SELECT premium_until FROM users WHERE id=?').get(q.params.id);if(!u)return r.status(404).json({error:'یافت نشد'});const m=+q.body.months||0,nu=m>0?Math.max(Date.now(),u.premium_until||0)+m*30*864e5:0;db.prepare('UPDATE users SET premium_until=? WHERE id=?').run(nu,q.params.id);r.json({premium_until:nu})}));
app.get('/api/admin/shops',AD,A((q,r)=>r.json(db.prepare("SELECT s.*,u.username,c.title ctitle FROM shops s JOIN users u ON u.id=s.user_id LEFT JOIN chats c ON c.id=s.chat_id ORDER BY (s.status='pending') DESC,s.id DESC LIMIT 100").all())));
app.put('/api/admin/shops/:id',AD,A((q,r)=>{const s=db.prepare('SELECT * FROM shops WHERE id=?').get(q.params.id);if(!s)return r.status(404).json({error:'یافت نشد'});const st=q.body.status==='approved'?'approved':'rejected';db.prepare('UPDATE shops SET status=? WHERE id=?').run(st,s.id);
 if(st==='approved')db.prepare('UPDATE users SET seller=1 WHERE id=?').run(s.user_id);else if(!db.prepare("SELECT 1 FROM shops WHERE user_id=? AND status='approved'").get(s.user_id))db.prepare('UPDATE users SET seller=0 WHERE id=?').run(s.user_id);r.json({ok:1})}));
app.get('/api/admin/users/:id/chats',AD,A((q,r)=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(q.params.id);r.json(u?listChats(u):[])}));
app.get('/api/admin/chats/:id/messages',AD,A((q,r)=>r.json(db.prepare(MSG()+' WHERE chat_id=? ORDER BY m.id DESC LIMIT 300').all(q.params.id).reverse())));


app.post('/api/admin/users/:id/stars',AD,A((q,r)=>{const n=Math.round(+q.body.amount*1000)/1000;if(!n||!db.prepare('SELECT 1 FROM users WHERE id=?').get(q.params.id))return r.status(400).json({error:'مقدار نامعتبر'});bal(+q.params.id,n,'admin','از طرف مدیریت');r.json({ok:1})}));
const mask=v=>v?'••••'+String(v).slice(-4):'';
app.get('/api/admin/pay',AD,(q,r)=>r.json({mode:get('pay_mode')||'normal',base:get('pay_base')||'https://tonpays.online',origin:get('pay_origin')||'',key:mask(get('pay_key')),secret:mask(get('pay_secret')),price:price(),k:sget('star_k',.002),spread:sget('star_spread',.05),floor:sget('star_floor',8000),fee:sget('shop_fee',.05),support:(db.prepare('SELECT username FROM users WHERE id=?').get(SUPPORT())||{}).username||''}));
app.put('/api/admin/pay',AD,A((q,r)=>{const b=q.body,sv=(k,v)=>{if(v!==undefined&&v!==null&&!String(v).startsWith('••••'))set(k,String(v).trim())};sv('pay_mode',b.mode==='custom'?'custom':'normal');sv('pay_base',b.base);sv('pay_origin',b.origin);sv('pay_key',b.key);sv('pay_secret',b.secret);
 [['star_k',b.k],['star_spread',b.spread],['star_floor',b.floor],['shop_fee',b.fee]].forEach(([k,v])=>{if(v!==undefined&&v!==''&&!isNaN(+v))set(k,+v)});if(b.price&&+b.price>0&&+b.price!==price())setPrice(+b.price);
 if(b.support){const u=find({username:b.support});if(!u)return r.status(400).json({error:'کاربر پشتیبانی پیدا نشد'});set('support_user',u.id)}r.json({ok:1})}));
app.get('/api/admin/plans',AD,(q,r)=>r.json(db.prepare('SELECT * FROM plans WHERE active=1 ORDER BY days').all()));
app.post('/api/admin/plans',AD,A((q,r)=>{const t=String(q.body.title||'').trim().slice(0,60),d=+q.body.days,p=+q.body.price;if(!t||!(d>0)||!(p>0))return r.status(400).json({error:'نام، تعداد روز و قیمت (سوریا استار) را بنویسید'});db.prepare('INSERT INTO plans(title,days,price) VALUES(?,?,?)').run(t,Math.round(d),p);r.json({ok:1})}));
app.delete('/api/admin/plans/:id',AD,(q,r)=>{db.prepare('UPDATE plans SET active=0 WHERE id=?').run(q.params.id);r.json({ok:1})});
app.get('/api/admin/orders',AD,A((q,r)=>r.json(db.prepare("SELECT o.id,o.price,o.status,o.dtext,o.dfile,o.dfname,p.title,b.username buyer,s.username seller FROM orders o JOIN products p ON p.id=o.product_id JOIN users b ON b.id=o.buyer_id JOIN users s ON s.id=o.seller_id WHERE o.status=? ORDER BY o.id DESC LIMIT 100").all(q.query.status||'delivered'))));
app.put('/api/admin/orders/:id',AD,A((q,r)=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(q.params.id);if(!o||!['delivered','paid'].includes(o.status))return r.status(400).json({error:'سفارش قابل بررسی نیست'});
 if(q.body.approve){if(o.status!=='delivered')return r.status(400).json({error:'فروشنده هنوز تحویل نداده'});const cut=Math.round(o.price*sget('shop_fee',.05)*1000)/1000;bal(o.seller_id,o.price-cut,'sale','فروش تایید شد');if(cut)bal(ADMINID(),cut,'income','کارمزد فروشگاه');db.prepare("UPDATE orders SET status='completed' WHERE id=?").run(o.id)}
 else{bal(o.buyer_id,o.price,'refund','بازگشت وجه');db.prepare("UPDATE orders SET status='refunded' WHERE id=?").run(o.id)}r.json({ok:1})}));
app.get('/api/admin/cashouts',AD,(q,r)=>r.json(db.prepare("SELECT c.*,u.username FROM cashouts c JOIN users u ON u.id=c.user_id WHERE c.status=? ORDER BY c.id DESC LIMIT 100").all(q.query.status||'pending')));
app.put('/api/admin/cashouts/:id',AD,A((q,r)=>{const c=db.prepare("SELECT * FROM cashouts WHERE id=? AND status='pending'").get(q.params.id);if(!c)return r.status(400).json({error:'یافت نشد'});
 if(q.body.paid)db.prepare("UPDATE cashouts SET status='paid' WHERE id=?").run(c.id);else{bal(c.user_id,c.stars,'refund','رد درخواست برداشت');db.prepare("UPDATE cashouts SET status='rejected' WHERE id=?").run(c.id)}r.json({ok:1})}));
io.use((s,n)=>{try{const u=db.prepare('SELECT banned FROM users WHERE id=?').get(jwt.verify(s.handshake.auth.token,SECRET).id);if(!u)throw 0;s.uid=jwt.verify(s.handshake.auth.token,SECRET).id;n()}catch{n(new Error('auth'))}});
io.on('connection',s=>s.join('u'+s.uid));
srv.listen(E.PORT||3000,()=>console.log('Soriany on :'+(E.PORT||3000)));
