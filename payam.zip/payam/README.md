# سوریانوی - راهنمای ساده

## بار اول (نصب)
1. در Cloudflare/پنل دامنه، رکورد A دامنه را روی IP سرور بگذارید (ابر Cloudflare خاکستری باشد).
2. فایل payam.zip را روی سرور بفرستید، بعد:
   apt install -y unzip && unzip -o payam.zip && cd payam && bash install.sh
3. دامنه (یا چند دامنه با فاصله) و ایمیل را وارد کنید. بقیه خودکار است.
4. وارد سایت شوید و **اول خودتان ثبت‌نام کنید** (می‌شوید ادمین).

## آپدیت (دفعات بعد - بدون پرسیدن دامنه)
   cd /root && unzip -o payam.zip && cd payam && bash update.sh

## دامنه‌ی جدید
   cd /root/payam && bash add-domain.sh

## دستورهای مفید
   systemctl status payam      وضعیت برنامه
   journalctl -u payam -n 50   دیدن خطاها
   بکاپ دیتابیس: /opt/payam/data.db  (و پوشه uploads)

## دستورات گپ (فقط وقتی روی پیام کسی ریپلای می‌کنید یا @یوزرنیم می‌نویسید)
   /ban /unban        مسدود کردن کلی کاربر (فقط ادمین)
   /mute [ساعت]       بی‌صدا کردن (مالک گروه و ادمین) - بدون عدد = دائمی
   /unmute            برداشتن بی‌صدایی
   /sick              بیرون انداختن از گروه (در گپ عمومی فقط ادمین)
   /tick /untick      تیک آبی (فقط ادمین)
   /seller /unseller  تگ فروشنده (فقط ادمین)
   /prem [ماه]        پریمیوم کردن، مثلا /prem 2   و   /unprem برای لغو

## ساخت اپلیکیشن اندروید با GitHub (خودکار)
1. کل پوشه payam را در یک مخزن GitHub بگذارید (Upload یا git push).
2. در GitHub: Settings > Secrets and variables > Actions > تب Variables > New repository variable
   نام: SERVER_URL      مقدار: https://دامنه-شما   (مثلا https://sorianoir.ir)
3. تب Actions > Build Android App > Run workflow (یا با هر push خودش اجرا می‌شود).
4. بعد از چند دقیقه در بخش Releases فایل APK آماده است. دانلود و نصب کنید.
همه‌ی صفحه‌ها و فونت داخل خود برنامه هستند و فقط اطلاعات از سرور گرفته می‌شود.
نسخه iOS نیاز به حساب Apple Developer و مک دارد و در این بسته نیست.

## پرداخت (TonPays)
ادمین > پنل مدیریت > درگاه، بورس و پشتیبانی: نوع درگاه (معمولی یا کاستوم وب)، کلید API، سکرت وبهوک و آدرس سایت را بنویسید.
آدرس وبهوک: https://دامنه-شما/api/pay/webhook
