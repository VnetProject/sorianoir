#!/bin/bash
# آپدیت سورس برنامه (بدون پرسیدن دامنه و ...). اطلاعات کاربران و فایل‌ها حفظ می‌شود.
set -e
[ "$EUID" -ne 0 ] && { echo "با root اجرا کنید:  sudo bash update.sh"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"; DIR=/opt/payam
[ -d "$DIR" ] || { echo "برنامه هنوز نصب نشده. اول bash install.sh را بزنید."; exit 1; }
mkdir -p /opt/payam-backups && cp -a $DIR/data.db /opt/payam-backups/data-$(date +%F-%H%M).db 2>/dev/null || true
rsync -a --exclude install.sh --exclude add-domain.sh --exclude update.sh --exclude .env --exclude 'data.db*' --exclude uploads --exclude node_modules --exclude app --exclude .github "$SRC"/ $DIR/
chown -R payam:payam $DIR
sudo -u payam bash -c "cd $DIR && npm install --omit=dev"
CONF=/etc/nginx/sites-available/payam
if [ -f $CONF ] && ! grep -q X-Forwarded-Proto $CONF; then sed -i 's#proxy_set_header Host \$host;#proxy_set_header Host $host; proxy_set_header X-Forwarded-Proto $scheme;#' $CONF && nginx -t && systemctl reload nginx; fi
systemctl restart payam
sleep 2; systemctl is-active payam && echo "آپدیت انجام شد."
