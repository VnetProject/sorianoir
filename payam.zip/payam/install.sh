#!/bin/bash
# نصب‌کننده خودکار پیام‌رسان - Ubuntu 24
set -e
[ "$EUID" -ne 0 ] && { echo "لطفاً با root اجرا کنید:  sudo bash install.sh"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"; DIR=/opt/payam
G='\033[1;32m'; R='\033[1;31m'; N='\033[0m'
say(){ echo -e "${G}▶ $1${N}"; }

echo "================ نصب پیام‌رسان ================"
read -rp "دامنه‌ها (اگر چند تا دارید با فاصله بنویسید، مثال: a.com b.ir): " DOMAINS
DOMAINS=$(echo "$DOMAINS" | sed 's#https\?://##g; s#/[^ ]*##g' | tr 'A-Z' 'a-z')
for D in $DOMAINS; do [[ "$D" =~ ^[a-z0-9.-]+\.[a-z]{2,}$ ]] || { echo -e "${R}دامنه نامعتبر: $D${N}"; exit 1; }; done
DOMAIN=${DOMAINS%% *}
read -rp "ایمیل شما (برای گواهی SSL): " EMAIL
read -rp "ارسال ایمیل تایید ثبت‌نام را فعال کنم؟ نیاز به اطلاعات SMTP دارد. (y/n) [n]: " USE_SMTP
if [[ "$USE_SMTP" == "y" ]]; then
  read -rp "  SMTP Host (مثال smtp.gmail.com): " SMTP_HOST
  read -rp "  SMTP Port [587]: " SMTP_PORT; SMTP_PORT=${SMTP_PORT:-587}
  read -rp "  SMTP Username: " SMTP_USER
  read -rsp "  SMTP Password: " SMTP_PASS; echo
  SMTP_FROM="پیام‌رسان <$SMTP_USER>"
fi

say "نصب پیش‌نیازها (چند دقیقه صبر کنید)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates nginx certbot python3-certbot-nginx build-essential python3 dnsutils ufw rsync
NV=$(node -v 2>/dev/null | cut -d. -f1 | tr -d v || echo 0)
if [ "${NV:-0}" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi

say "بررسی دامنه‌ها..."
SIP=$(curl -4 -s https://ifconfig.me || true)
for D in $DOMAINS; do DIP=$(dig +short A "$D" | tail -1)
  if [ "$SIP" != "$DIP" ]; then
    echo -e "${R}هشدار: $D روی $DIP اشاره می‌کند ولی IP این سرور $SIP است.${N}"
    echo "در DNS یک رکورد A به IP سرور بسازید (در Cloudflare ابر را خاکستری کنید) و چند دقیقه صبر کنید."
    read -rp "با این حال ادامه بدهم؟ (y/n) [n]: " C; [[ "$C" == "y" ]] || exit 1
  fi
done
echo "$DOMAINS" > /opt/payam-domains.txt

say "کپی برنامه..."
id payam &>/dev/null || useradd -r -m -d $DIR -s /usr/sbin/nologin payam
mkdir -p $DIR
OLD_SECRET=$(grep -s '^JWT_SECRET=' $DIR/.env | cut -d= -f2-)
rsync -a --exclude install.sh --exclude node_modules --exclude .env --exclude data.db\* --exclude uploads --exclude app --exclude .github "$SRC"/ $DIR/
SECRET=${OLD_SECRET:-$(head -c 32 /dev/urandom | base64 | tr -dc A-Za-z0-9)}
cat > $DIR/.env <<EOT
PORT=3000
JWT_SECRET=$SECRET
SMTP_HOST=${SMTP_HOST:-}
SMTP_PORT=${SMTP_PORT:-587}
SMTP_USER=${SMTP_USER:-}
SMTP_PASS=${SMTP_PASS:-}
SMTP_FROM=${SMTP_FROM:-}
EOT
chmod 600 $DIR/.env
chown -R payam:payam $DIR
say "نصب کتابخانه‌ها..."
sudo -u payam bash -c "cd $DIR && npm install --omit=dev"

say "ساخت سرویس (دیتابیس هنگام اولین اجرا خودکار ساخته می‌شود)..."
cat > /etc/systemd/system/payam.service <<EOT
[Unit]
Description=Payam Messenger
After=network.target
[Service]
User=payam
WorkingDirectory=$DIR
ExecStart=/usr/bin/node server.js
Restart=always
[Install]
WantedBy=multi-user.target
EOT
systemctl daemon-reload; systemctl enable --now payam; systemctl restart payam

say "تنظیم Nginx..."
cat > /etc/nginx/sites-available/payam <<EOT
server {
  listen 80; server_name $DOMAINS;
  client_max_body_size 60M;
  location / {
    proxy_pass http://127.0.0.1:3000; proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade; proxy_set_header Connection "upgrade";
    proxy_set_header Host \$host; proxy_set_header X-Forwarded-Proto \$scheme; proxy_set_header X-Forwarded-For \$remote_addr;
  }
}
EOT
ln -sf /etc/nginx/sites-available/payam /etc/nginx/sites-enabled/payam
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl enable nginx && systemctl restart nginx

say "دریافت SSL..."
CB=""; for D in $DOMAINS; do CB="$CB -d $D"; done
if certbot --nginx --cert-name payam $CB --non-interactive --agree-tos -m "$EMAIL" --redirect --expand; then
  echo -e "\n${G}نصب کامل شد! آدرس‌ها:${N}"; for D in $DOMAINS; do echo "   https://$D"; done
else
  echo -e "\n${R}SSL گرفته نشد (معمولاً چون DNS هنوز درست نیست). سایت روی http کار می‌کند.${N}"
  echo "بعد از درست شدن DNS دوباره بزنید:  bash install.sh"
fi
echo "همین حالا وارد سایت شوید و اولین ثبت‌نام را خودتان انجام دهید؛ آن حساب «ادمین» می‌شود."
echo "برای دیدن خطاها:  journalctl -u payam -n 50"
